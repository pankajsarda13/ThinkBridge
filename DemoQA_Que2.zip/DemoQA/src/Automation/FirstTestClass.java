package Automation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTestClass {

	@SuppressWarnings("null")
	public static void main(String[] args) throws InterruptedException, Exception {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse_Workspace\\Selenium\\chromedriver.exe");

		// Create a driver object of Firefox class
		WebDriver driver = new ChromeDriver();
		try {

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to URL
		driver.get("http://jt-dev.azurewebsites.net/#/SignUp");

		
		// Validate that the dropdown has "English" and "Dutch"
		driver.findElement(By.xpath("//*[@id=\"language\"]/div[1]/span")).click();
		List<WebElement> list = driver.findElements(By.xpath("//*[@class='ui-select-choices-row-inner']"));
		// System.out.println("List size is:"+list.size());
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Element is:" + list.get(i).getText());
			if (list.get(i).getText().equals("English")) {
				System.out.println("English value of dropdown is verified");
			}
			if (list.get(i).getText().equals("Dutch")) {
				System.out.println("Dutch value of dropdown is verified");
			}
		}

		// Enter text in FullName Textbox
		WebElement fullname = driver.findElement(By.xpath("//*[@id='name']"));
		fullname.sendKeys("Pankaj");
		Thread.sleep(1000);

		// Enter text in Organization Textbox
		WebElement org = driver.findElement(By.xpath("//*[@id='orgName']"));
		System.out.println(driver.findElement(By.xpath("//*[@id='name']")).getAttribute("value") + "ShopBridge");
		org.sendKeys(driver.findElement(By.xpath("//*[@id='name']")).getAttribute("value") + "ShopBridge");
		Thread.sleep(1000);

		// Enter text in email address
		WebElement email = driver.findElement(By.xpath("//*[@id='singUpEmail']"));
		email.sendKeys("pankajsarda13@gmail.com");
		Thread.sleep(1000);
		
		// Select checkbox and click on "SignUp"
		driver.findElement(By.xpath("//*[@class='black-color ng-binding']")).click();
		driver.findElement(By.xpath("//*[@class='form-group custom-form-group']")).click();
		Thread.sleep(10000);
		String alert = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[3]/div/section/div[1]/form/div"))
				.getText();
		System.out.println("Alert after mail sent is:" + alert);

		

		// Validate Email sent
		if (alert != null || !alert.isEmpty()) {
			System.out.println("Email sent successfully");
		} else {
			System.out.println("Email not sent");
		}

		System.out.println("Execution complete");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	finally {
		Thread.sleep(5000);
		driver.quit();
	}

	}

}
